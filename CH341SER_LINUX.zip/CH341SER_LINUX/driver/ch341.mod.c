#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x8e17b3ae, "idr_destroy" },
	{ 0x54b1fac6, "__ubsan_handle_load_invalid_value" },
	{ 0x69acdf38, "memcpy" },
	{ 0xdb115302, "usb_autopm_get_interface_async" },
	{ 0xe9c943cc, "usb_anchor_urb" },
	{ 0x502bb2a1, "usb_autopm_get_interface" },
	{ 0x6bf5b6ff, "usb_control_msg" },
	{ 0x4c03a563, "random_kmalloc_seed" },
	{ 0xa63b4eed, "kmalloc_caches" },
	{ 0x59ffeca6, "kmalloc_trace" },
	{ 0x37a0cba, "kfree" },
	{ 0xb6209145, "usb_ifnum_to_if" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xb8f11603, "idr_alloc" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xc2d2f06d, "tty_port_init" },
	{ 0x9e87fbdc, "usb_alloc_coherent" },
	{ 0x1b06561d, "usb_alloc_urb" },
	{ 0x7665a95b, "idr_remove" },
	{ 0x850f7662, "usb_free_coherent" },
	{ 0x646397e6, "_dev_info" },
	{ 0x19be640e, "usb_driver_claim_interface" },
	{ 0x31b9e9c7, "usb_get_intf" },
	{ 0x40d23ba0, "tty_port_register_device" },
	{ 0xb3e4b07e, "usb_free_urb" },
	{ 0x85fb4898, "__tty_insert_flip_string_flags" },
	{ 0x52059c20, "tty_flip_buffer_push" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x20978fb9, "idr_find" },
	{ 0x19b0b095, "tty_standard_install" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0x2d3385d3, "system_wq" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xc6cbbc89, "capable" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xaad8c7d6, "default_wake_function" },
	{ 0x1e362ae8, "pcpu_hot" },
	{ 0x4afb2238, "add_wait_queue" },
	{ 0x1000e51, "schedule" },
	{ 0x37110088, "remove_wait_queue" },
	{ 0xcd9c13a3, "tty_termios_hw_change" },
	{ 0xbd394d8, "tty_termios_baud_rate" },
	{ 0xc6c065f4, "usb_put_intf" },
	{ 0xa97af4a0, "tty_port_tty_get" },
	{ 0xa12120da, "tty_vhangup" },
	{ 0xc21f5f00, "tty_kref_put" },
	{ 0xaa769b02, "tty_unregister_device" },
	{ 0x2f8d0f75, "usb_driver_release_interface" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x3e1c9c49, "usb_submit_urb" },
	{ 0x1e898af9, "_dev_err" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x38c72975, "usb_autopm_put_interface_async" },
	{ 0xc2ca6115, "usb_kill_urb" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x8427cc7b, "_raw_spin_lock_irq" },
	{ 0x4b750f53, "_raw_spin_unlock_irq" },
	{ 0x985e1ae0, "tty_port_put" },
	{ 0x268fa4e1, "__tty_alloc_driver" },
	{ 0x67b27ec1, "tty_std_termios" },
	{ 0x1f347b8d, "tty_register_driver" },
	{ 0x97c4004d, "usb_register_driver" },
	{ 0x122c3a7e, "_printk" },
	{ 0xe70c0059, "tty_unregister_driver" },
	{ 0x68c6fd0, "tty_driver_kref_put" },
	{ 0x6ebe366f, "ktime_get_mono_fast_ns" },
	{ 0xe2964344, "__wake_up" },
	{ 0xc30e0641, "__dynamic_dev_dbg" },
	{ 0xd4a7e4ff, "tty_port_tty_hangup" },
	{ 0x788a9420, "usb_autopm_get_interface_no_resume" },
	{ 0x4e2d81ff, "usb_autopm_put_interface" },
	{ 0xebcd0d5e, "usb_get_from_anchor" },
	{ 0x428620ad, "tty_port_tty_wakeup" },
	{ 0x4770c79b, "tty_port_hangup" },
	{ 0xf4ed414f, "tty_port_close" },
	{ 0xd6cf02b6, "tty_port_open" },
	{ 0x1b613147, "usb_deregister" },
	{ 0xf079b8f9, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v1A86p7523d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1A86p7522d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1A86p5523d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1A86pE523d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v4348p5523d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "8B035E6078723C06DFB968D");
